<?php
if (!defined('ABSPATH')) {
    exit;
}
require_once __DIR__ . '/acf-sync.php';

require_once __DIR__ . '/languages.php';

add_action('rest_api_init', function () {
    register_rest_route('omb-headless/v1', '/site', [
        'methods'             => 'GET',
        'permission_callback' => '__return_true',
        'callback'            => 'omb_rest_get_site_payload',
    ]);

    register_rest_route('omb-headless/v1', '/route', [
        'methods'             => 'GET',
        'permission_callback' => '__return_true',
        'callback'            => 'omb_rest_resolve_route',
        'args'                => [
            'path' => [
                'required'          => true,
                'sanitize_callback' => 'sanitize_text_field',
            ],
            'lang' => [
                'required'          => false,
                'sanitize_callback' => 'sanitize_text_field',
            ],
        ],
    ]);

    register_rest_route('omb-headless/v1', '/globals', [
        'methods'             => 'GET',
        'permission_callback' => '__return_true',
        'callback'            => 'omb_rest_get_globals',
        'args'                => [
            'lang' => [
                'required'          => false,
                'sanitize_callback' => 'sanitize_text_field',
            ],
        ],
    ]);

    register_rest_route('omb-headless/v1', '/reading', [
        'methods'             => 'GET',
        'permission_callback' => '__return_true',
        'callback'            => 'omb_rest_get_reading',
        'args'                => [
            'lang' => [
                'required'          => false,
                'sanitize_callback' => 'sanitize_text_field',
            ],
        ],
    ]);

    register_rest_route('omb-headless/v1', '/acf-sync', [
        'methods'             => 'POST',
        'permission_callback' => function (WP_REST_Request $request) {
            $secret = $request->get_header('X-Sync-Secret');
            // Try wp_options first, then ACF options field as fallback
            $stored = get_option('omb_revalidation_secret', '');
            if (empty($stored) && function_exists('get_field')) {
                $stored = get_field('revalidation_secret', 'option') ?: '';
            }
            if (empty($stored)) {
                return new WP_Error(
                    'missing_secret',
                    'Sync secret is not configured in WordPress.',
                    ['status' => 500]
                );
            }
            return hash_equals((string) $stored, (string) $secret);
        },
        'callback' => 'omb_rest_acf_sync',
    ]);

    register_rest_route('omb-headless/v1', '/acf-sync-status', [
        'methods'             => 'GET',
        'permission_callback' => '__return_true',
        'callback'            => function () {
            $stored = get_option('omb_revalidation_secret', '');
            if (empty($stored) && function_exists('get_field')) {
                $stored = get_field('revalidation_secret', 'option') ?: '';
            }
            return new WP_REST_Response([
                'route_loaded'  => true,
                'secret_found'  => !empty($stored),
                'secret_length'     => strlen($stored),
                'merge_supported'   => function_exists('omb_rest_acf_prepare_groups_for_import'),
                'append_supported'  => function_exists('omb_rest_acf_append_layouts_to_field'),
                'page_sections_layout_count' => count(omb_rest_acf_page_sections_layout_names()),
                'page_sections_layouts'      => omb_rest_acf_page_sections_layout_names(),
            ], 200);
        },
    ]);
});

/**
 * ACF option page slugs (must match acf_add_options_sub_page menu_slug values).
 */
function omb_rest_globals_option_slugs(): array {
    return [
        'header'         => 'omb-header-settings',
        'footer'         => 'omb-footer-settings',
        'contact'        => 'omb-contact-social',
        'site'           => 'omb-site-settings',
        'integrations'   => 'omb-integrations',
        'defaultSeo'     => 'omb-default-seo',
        'templates'      => 'omb-templates-settings',
    ];
}

/**
 * Field names per options page (OMB ACF bundle). Used when values share one ACF
 * options post_id ("option" / "options") instead of the menu_slug.
 *
 * @return array<string, list<string>>
 */
function omb_rest_globals_field_keys_by_menu_slug(): array {
    return [
        'omb-header-settings' => [
            'header_logo',
            'header_logo_dark',
            'header_style',
            'header_sticky',
            'show_language_switcher',
            'show_header_cta',
            'header_cta_link',
        ],
        'omb-footer-settings' => [
            'footer_title',
            'footer_text',
            'footer_logo',
            'footer_background_image',
            'footer_background_color',
            'footer_background_gradient',
            'footer_top_shape_image',
            'footer_cta_text',
            'footer_cta_primary_link',
            'footer_cta_secondary_link',
            'footer_cta_2_link',
            'footer_copyright',
            'show_footer_language_switcher',
        ],
        'omb-contact-social' => [
            'main_email',
            'main_phone',
            'address',
            'whatsapp',
            'linkedin_url',
            'instagram_url',
            'facebook_url',
            'youtube_url',
        ],
        'omb-site-settings' => [
            'site_name_override',
            'default_tagline',
            'default_og_image',
            'global_cta_title',
            'global_cta_text',
            'global_cta_link',
            'enable_announcement',
            'announcement_text',
            'announcement_link',
        ],
        'omb-integrations' => [
            'gtm_id',
            'ga4_id',
            'next_frontend_url',
            'revalidation_secret',
            'default_contact_form',
        ],
        'omb-default-seo' => [
            'default_seo_title_pattern',
            'default_seo_description',
            'default_share_image',
            'allow_indexing_by_default',
        ],
        'omb-templates-settings' => [
            'blog_single_sections',
            'show_related_posts',
        ],
    ];
}

/**
 * @param array<string, mixed> $source
 * @param list<string>         $keys
 *
 * @return array<string, mixed>
 */
function omb_rest_globals_pick_keys(array $source, array $keys): array {
    $out = [];
    foreach ($keys as $key) {
        if (array_key_exists($key, $source)) {
            $out[$key] = $source[$key];
        }
    }
    return $out;
}

/**
 * Merge every `footer_*` key from the flat options array into the footer chunk.
 * New ACF fields are included even if this plugin's allowlist was not redeployed yet.
 *
 * @param array<string, mixed> $flat
 * @param array<string, mixed> $footer_chunk
 *
 * @return array<string, mixed>
 */
function omb_rest_globals_merge_footer_keys_from_flat(array $flat, array $footer_chunk): array {
    foreach ($flat as $key => $value) {
        if (is_string($key) && strpos($key, 'footer_') === 0) {
            $footer_chunk[$key] = $value;
        }
    }
    return $footer_chunk;
}

/**
 * Resolve attachment IDs / incomplete image arrays to absolute URLs for headless apps.
 *
 * @param array<string, mixed> $footer
 */
function omb_rest_normalize_footer_image_urls(array &$footer): void {
    $keys = ['footer_background_image', 'footer_top_shape_image', 'footer_logo'];
    foreach ($keys as $key) {
        if (!array_key_exists($key, $footer)) {
            continue;
        }
        $v = $footer[$key];
        $id = 0;
        if (is_numeric($v)) {
            $id = (int) $v;
        } elseif (is_array($v)) {
            $has_url = !empty($v['url']) && is_string($v['url']) && $v['url'] !== '' && $v['url'] !== 'false';
            if ($has_url) {
                $url_str = (string) $v['url'];
                if ($url_str !== '' && $url_str[0] === '/' && strncmp($url_str, '//', 2) !== 0) {
                    $footer[$key] = array_merge($v, ['url' => home_url($url_str)]);
                }
                continue;
            }
            if (!empty($v['ID'])) {
                $id = (int) $v['ID'];
            } elseif (!empty($v['id'])) {
                $id = (int) $v['id'];
            }
        }
        if ($id <= 0 || !function_exists('wp_get_attachment_image_url')) {
            continue;
        }
        $url = wp_get_attachment_image_url($id, 'full');
        if (!$url) {
            continue;
        }
        if (is_array($v)) {
            $footer[$key] = array_merge($v, ['url' => $url, 'ID' => $id, 'id' => $id]);
        } else {
            $footer[$key] = ['url' => $url, 'ID' => $id, 'id' => $id];
        }
    }
}

/**
 * ACF resolves options storage post_id per page; subpages often default to "option" / "options".
 */
function omb_rest_globals_resolve_acf_post_id(string $menu_slug): string {
    if (function_exists('acf_get_options_page')) {
        $page = acf_get_options_page($menu_slug);
        if (is_array($page) && !empty($page['post_id'])) {
            return (string) $page['post_id'];
        }
    }
    return $menu_slug;
}

/**
 * @return array<string, mixed>|false
 */
function omb_rest_globals_get_fields_for_post_id(string $post_id) {
    if (!function_exists('get_fields')) {
        return false;
    }

    return get_fields($post_id);
}

/**
 * Load globals. ACF sub-options often share post_id "option" or "options" (not the menu_slug), so try those
 * first and partition by field name. Otherwise load each page's resolved post_id (or menu_slug).
 *
 * @return array<string, array<string, mixed>>
 */
function omb_rest_globals_collect_fields(): array {
    $response_keys = omb_rest_globals_option_slugs();
    $keys_by_slug = omb_rest_globals_field_keys_by_menu_slug();
    $out = [];

    foreach (['option', 'options'] as $bucket) {
        $flat = omb_rest_globals_get_fields_for_post_id($bucket);
        if (!is_array($flat) || $flat === []) {
            continue;
        }
        foreach ($response_keys as $response_key => $menu_slug) {
            $names = $keys_by_slug[$menu_slug] ?? [];
            $chunk = omb_rest_globals_pick_keys($flat, $names);
            if ($response_key === 'footer') {
                $chunk = omb_rest_globals_merge_footer_keys_from_flat($flat, $chunk);
            }
            $out[$response_key] = $chunk;
        }
        return $out;
    }

    foreach ($response_keys as $response_key => $menu_slug) {
        $names = $keys_by_slug[$menu_slug] ?? [];
        $candidates = array_unique(
            array_filter(
                [
                    omb_rest_globals_resolve_acf_post_id($menu_slug),
                    $menu_slug,
                ],
                static function ($id) {
                    return $id !== '' && $id !== 'option' && $id !== 'options';
                }
            )
        );
        $chunk = [];
        foreach ($candidates as $post_id) {
            $fields = omb_rest_globals_get_fields_for_post_id($post_id);
            if (is_array($fields) && $fields !== []) {
                $chunk = $names ? omb_rest_globals_pick_keys($fields, $names) : $fields;
                if ($response_key === 'footer') {
                    $chunk = omb_rest_globals_merge_footer_keys_from_flat($fields, $chunk);
                }
                break;
            }
        }
        $out[$response_key] = $chunk;
    }

    return $out;
}

/**
 * Match Polylang language for REST callbacks (Reading, globals, etc.).
 */
function omb_rest_switch_polylang_lang(?string $lang): void {
    if ($lang === null || $lang === '') {
        return;
    }
    if (!function_exists('PLL')) {
        return;
    }
    $pll = PLL();
    if ($pll && is_callable([$pll, 'switch_language'])) {
        $pll->switch_language($lang);
    } elseif ($pll && isset($pll->model) && is_object($pll->model)) {
        $pll_lang = $pll->model->get_language($lang);
        if ($pll_lang) {
            $pll->curlang = $pll_lang;
        }
    }
}

/**
 * Settings ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â€šÂ¬Ã‚Â ÃƒÂ¢Ã¢â€šÂ¬Ã¢â€žÂ¢ Reading: static front page slug for the active (switched) language.
 *
 * @return array{show_on_front: string, homepage_slug: string|null}
 */
function omb_rest_reading_home_payload(): array {
    $show = (string) get_option('show_on_front');
    if ($show !== 'page') {
        return [
            'show_on_front'   => $show,
            'homepage_slug'   => null,
        ];
    }
    $page_id = (int) get_option('page_on_front');
    if ($page_id <= 0) {
        return [
            'show_on_front'   => $show,
            'homepage_slug'   => null,
        ];
    }
    $post = get_post($page_id);
    if (!$post || $post->post_type !== 'page' || $post->post_status !== 'publish') {
        return [
            'show_on_front'   => $show,
            'homepage_slug'   => null,
        ];
    }

    return [
        'show_on_front' => $show,
        'homepage_slug' => $post->post_name,
    ];
}

function omb_rest_get_reading(WP_REST_Request $request): WP_REST_Response {
    $lang = (string) $request->get_param('lang');
    omb_rest_switch_polylang_lang($lang !== '' ? $lang : null);

    return new WP_REST_Response(omb_rest_reading_home_payload(), 200);
}

/**
 * Expose ACF global option groups for headless frontends when the ACF REST namespace
 * is unavailable (common). Uses get_fields() server-side so image fields include URLs.
 */
function omb_rest_get_globals(WP_REST_Request $request): WP_REST_Response {
    if (!function_exists('get_fields')) {
        return new WP_REST_Response(
            ['error' => 'acf_inactive', 'message' => 'Advanced Custom Fields is required for globals.'],
            503
        );
    }

    $lang = (string) $request->get_param('lang');
    omb_rest_switch_polylang_lang($lang !== '' ? $lang : null);

    $out = omb_rest_globals_collect_fields();
    $out['reading'] = omb_rest_reading_home_payload();

    if (!empty($out['footer']) && is_array($out['footer'])) {
        omb_rest_normalize_footer_image_urls($out['footer']);
    }

    return new WP_REST_Response($out, 200);
}

function omb_rest_get_site_payload(WP_REST_Request $request): WP_REST_Response {
    return new WP_REST_Response([
        'name' => get_bloginfo('name'),
        'description' => get_bloginfo('description'),
        'url' => home_url('/'),
        'languages' => omb_get_available_languages(),
        'menus' => [
            'primary' => has_nav_menu('primary'),
            'footer' => has_nav_menu('footer'),
            'legal' => has_nav_menu('legal'),
        ],
    ]);
}

function omb_rest_resolve_route(WP_REST_Request $request): WP_REST_Response {
    $raw_path = trim((string) $request->get_param('path'), '/');
    $lang = (string) $request->get_param('lang');

    $query = new WP_Query([
        'name'              => basename($raw_path),
        'post_type'         => ['page', 'post', 'service', 'case_study'],
        'post_status'       => 'publish',
        'posts_per_page'    => 1,
        'no_found_rows'     => true,
        'suppress_filters'  => false,
        'lang'              => $lang ?: '',
    ]);

    if (!$query->have_posts()) {
        return new WP_REST_Response(['found' => false], 404);
    }

    $post = $query->posts[0];
    $translations = [];

    if (function_exists('pll_get_post_translations')) {
        foreach (pll_get_post_translations($post->ID) as $translation_lang => $translation_id) {
            $translations[] = [
                'lang' => $translation_lang,
                'id'   => $translation_id,
                'uri'  => get_permalink($translation_id),
            ];
        }
    }

    return new WP_REST_Response([
        'found'        => true,
        'id'           => $post->ID,
        'type'         => get_post_type($post),
        'slug'         => $post->post_name,
        'uri'          => get_permalink($post),
        'lang'         => function_exists('pll_get_post_language') ? pll_get_post_language($post->ID, 'slug') : null,
        'translations' => $translations,
    ]);
}

function omb_rest_user_plain_bio(string $html): string {
    return trim(wp_strip_all_tags($html));
}

/** Sanitize optional author social URL for REST JSON. */
function omb_rest_author_social_url(string $raw): string {
    $t = trim($raw);
    if ($t === '') {
        return '';
    }
    $u = esc_url_raw($t);
    if (is_string($u) && $u !== '') {
        return $u;
    }
    // esc_url_raw() drops fragment-only values (e.g. ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€¦Ã¢â‚¬Å“#ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â placeholders in dev); keep them for headless UI stubs.
    if ($t === '#') {
        return '#';
    }

    return '';
}

/**
 * First non-empty user meta string among common keys (ACF / profile field names vary).
 *
 * @param list<string> $keys
 */
function omb_rest_user_meta_first_string(int $user_id, array $keys): string {
    foreach ($keys as $key) {
        if (!is_string($key) || $key === '') {
            continue;
        }
        $v = get_user_meta($user_id, $key, true);
        if (is_string($v)) {
            $t = trim($v);
            if ($t !== '') {
                return $t;
            }
        }
    }

    return '';
}

/**
 * @return string HTML or plain bio (same shape as `description` in REST)
 */
function omb_rest_user_description_for_lang(int $user_id, string $lang_slug): string {
    $slug = sanitize_key($lang_slug);
    if ($slug === '') {
        return '';
    }

    omb_rest_switch_polylang_lang($slug);

    $read = static function (int $uid, string $meta_key): string {
        $v = get_user_meta($uid, $meta_key, true);
        return is_string($v) ? $v : '';
    };

    $suffixes = [$slug];
    if (function_exists('PLL') && isset(PLL()->model)) {
        $lang_obj = PLL()->model->get_language($slug);
        if ($lang_obj && !empty($lang_obj->locale)) {
            $loc = (string) $lang_obj->locale;
            $suffixes[] = strtolower(str_replace('-', '_', $loc));
            $suffixes[] = $loc;
        }
    }
    $suffixes = array_values(array_unique(array_filter($suffixes)));

    // Prefer locale-specific keys first: default `description` often holds English while Polylang
    // stores Nederlands in `description_nl` / `description_nl_nl` ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬ÃƒÂ¢Ã¢â€šÂ¬Ã‚Â so `?lang=nl` must not stop at English.
    foreach ($suffixes as $suffix) {
        foreach (['description_' . $suffix, 'description-' . $suffix, 'pll_description_' . $suffix] as $key) {
            $raw = $read($user_id, $key);
            if ($raw !== '' && omb_rest_user_plain_bio($raw) !== '') {
                return $raw;
            }
        }
    }

    $fallback = $read($user_id, 'description');
    if ($fallback !== '' && omb_rest_user_plain_bio($fallback) !== '') {
        return $fallback;
    }

    return '';
}

/**
 * @param WP_REST_Response $response
 */
function omb_rest_prepare_user_i18n_description($response, WP_User $user, WP_REST_Request $request) {
    $data = $response->get_data();
    if (!is_array($data)) {
        return $response;
    }

    $uid = (int) $user->ID;
    $data['omb_author_social'] = [
        'facebook' => omb_rest_author_social_url(
            omb_rest_user_meta_first_string(
                $uid,
                [
                    'omb_author_facebook',
                    'facebook_profile_url',
                    'facebook_url',
                    'facebook',
                ]
            )
        ),
        'instagram' => omb_rest_author_social_url(
            omb_rest_user_meta_first_string(
                $uid,
                [
                    'omb_author_instagram',
                    'instagram_profile_url',
                    'instagram_url',
                    'instagram',
                ]
            )
        ),
        'linkedin' => omb_rest_author_social_url(
            omb_rest_user_meta_first_string(
                $uid,
                [
                    'omb_author_linkedin',
                    'linkedin_profile_url',
                    'linkedin_url',
                    'linkedin',
                ]
            )
        ),
    ];

    $lang = $request->get_param('lang');
    if (is_string($lang) && $lang !== '') {
        $bio = omb_rest_user_description_for_lang($uid, $lang);
        if ($bio !== '') {
            $data['description'] = $bio;
        }
    }

    $response->set_data($data);

    return $response;
}

add_filter('rest_prepare_user', 'omb_rest_prepare_user_i18n_description', 20, 3);
